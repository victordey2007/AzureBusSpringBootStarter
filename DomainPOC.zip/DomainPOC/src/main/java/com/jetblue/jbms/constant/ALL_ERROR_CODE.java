package com.jetblue.jbms.constant;

/**
 * 
 * @author anksingh
 *
 */
public enum ALL_ERROR_CODE {
	GLDSRV0001,
	GLDCUSDAO0001,
	GLDPAXDAO0001,
	GLDFLTDAO0001,
	GLDTRF0001,
	GLDTRF0002
}
