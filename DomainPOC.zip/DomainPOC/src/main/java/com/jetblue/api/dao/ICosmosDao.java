package com.jetblue.api.dao;



import com.jetblue.jbms.api.exception.model.DomainException;


public interface ICosmosDao {
	public void saveData(Object nm)throws DomainException;
}
