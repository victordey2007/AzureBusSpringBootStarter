package com.jetblue.jbms.transformimpl;

import org.springframework.stereotype.Component;

import com.google.gson.Gson;

import com.jetblue.jbms.api.exception.model.DomainException;
import com.jetblue.jbms.api.model.notification.NotificationRequest;
import com.jetblue.jbms.constant.ALL_ERROR_CODE;
import com.jetblue.jbms.transformer.INotificationTransformer;
@Component
public class NotificationTransformerImpl implements INotificationTransformer {

	@Override
	public NotificationRequest transformRequest(String data) throws DomainException {
		// TODO Auto-generated method stub
		try 
		{
		NotificationRequest nm=new Gson().fromJson(data, NotificationRequest.class);
		return nm;
		}catch (Exception e)
		{
			throw new DomainException(ALL_ERROR_CODE.GLDFLTDAO0001.toString(),"111" , "transformRequest", e);
		}
		
	}
 
	
}
