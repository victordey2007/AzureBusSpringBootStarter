package com.jetblue.azure.jbms.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
@Configuration
@ConfigurationProperties(prefix = "azure.servicebus")
public class SrvBUSProperties {
	private int maxConcurrentSessions;
	private int maxConcurrentCallsPerSession;
	private boolean autoComplete;
	private int maxAutoRenewDuration;
	private int messageWaitDuration;
	public int getMaxConcurrentSessions() {
		return maxConcurrentSessions;
	}
	public void setMaxConcurrentSessions(int maxConcurrentSessions) {
		this.maxConcurrentSessions = maxConcurrentSessions;
	}
	public int getMaxConcurrentCallsPerSession() {
		return maxConcurrentCallsPerSession;
	}
	public void setMaxConcurrentCallsPerSession(int maxConcurrentCallsPerSession) {
		this.maxConcurrentCallsPerSession = maxConcurrentCallsPerSession;
	}
	public boolean isAutoComplete() {
		return autoComplete;
	}
	public void setAutoComplete(boolean autoComplete) {
		this.autoComplete = autoComplete;
	}
	public int getMaxAutoRenewDuration() {
		return maxAutoRenewDuration;
	}
	public void setMaxAutoRenewDuration(int maxAutoRenewDuration) {
		this.maxAutoRenewDuration = maxAutoRenewDuration;
	}
	public int getMessageWaitDuration() {
		return messageWaitDuration;
	}
	public void setMessageWaitDuration(int messageWaitDuration) {
		this.messageWaitDuration = messageWaitDuration;
	}
	
	
	

}
