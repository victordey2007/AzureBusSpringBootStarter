package com.jetblue.jbms.api.handlerimpl;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jetblue.jbms.api.exception.model.DomainException;
import com.jetblue.jbms.api.handler.IDomainHandler;

import com.jetblue.jbms.services.IDomainService;
import com.microsoft.azure.servicebus.ExceptionPhase;
import com.microsoft.azure.servicebus.IMessage;
import com.microsoft.azure.servicebus.IMessageSession;

@Component
public class DomainHandlerImpl  implements  IDomainHandler{
	
	@Autowired
	private IDomainService service;


	public void notifyException(Throwable exception, ExceptionPhase phase) {
	        System.out.println(phase + " encountered exception:" + exception.getMessage());
	    }

		@Override
		public CompletableFuture<Void> OnCloseSessionAsync(IMessageSession arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public CompletableFuture<Void> onMessageAsync(IMessageSession arg0, IMessage arg1) {
			// TODO Auto-generated method stub
			
	       
	        	
					service.PersistAndPublishSegregatedNMRequest(arg1);
				 
			
	        return CompletableFuture.completedFuture(null);
		}
}
