package com.jetblue.jbms.service.impl;

import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.jetblue.api.dao.IBlobDao;
import com.jetblue.api.dao.ICosmosDao;
import com.jetblue.jbms.api.exception.model.DomainException;

import com.jetblue.jbms.api.model.notification.NotificationRequest;
import com.jetblue.jbms.constant.ALL_CONSTANTS;
import com.jetblue.jbms.services.IDomainService;
import com.jetblue.jbms.transformer.INotificationTransformer;
import com.microsoft.azure.servicebus.IMessage;
import com.microsoft.azure.servicebus.Message;
import com.microsoft.azure.servicebus.TopicClient;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;

@Component
public class DomainServiceImpl implements IDomainService{
//	private static final Logger log = LoggerFactory.getLogger(ALL_CONSTANTS.LOG_MODULE_NAME.getValue());
	@Autowired
	private IBlobDao blobDaoImpl;
	@Autowired
	private INotificationTransformer transformer;
	
	@Autowired
	private ICosmosDao cosmosDaoImpl;
	@Qualifier("outboundtopic")
	@Autowired
	private TopicClient outboundtopic;
	
	






	@Override
	public void PersistAndPublishSegregatedNMRequest(IMessage message)  {
		// TODO Auto-generated method stub
		
		 
			
		   	String szPlainTextMessage = new String(message.getBody(), StandardCharsets.UTF_8);
		   
		   		
		   		try {
		   		//	log.debug("Message Received"+szPlainTextMessage);
				   	NotificationRequest nm=transformer.transformRequest(szPlainTextMessage);
				     //	log.info(ALL_CONSTANTS.LOG_PREFIX.getValue() +  " request received from ServiceBus").field("request", nm).log();
				       
				
					blobDaoImpl.uploadData("test11/test11.txt", szPlainTextMessage);
					cosmosDaoImpl.saveData(nm);
					 Message message1 = new Message("output message");
					 outboundtopic.send(message1);
				} catch (DomainException e) {
					// TODO Auto-generated catch block
				//	log.error("ERROR-DomainException"+ e.getErrorResponse());
				}
		   		catch (InterruptedException e) {
					// TODO Auto-generated catch block
		   			//log.error("ERROR-InterruptedException"+ e.getMessage());
				} catch (ServiceBusException e) {
					// TODO Auto-generated catch block
					//log.error("ERROR-ServiceBusException"+ e.getMessage());
				
		  
		   	
		   	}
	}
	}


