package com.jetblue.api.dao;

import com.jetblue.jbms.api.exception.model.DomainException;

public interface IBlobDao {
	public void uploadData(String blobPath,String body) throws DomainException;
}
