It has the following functionality.
1.       Service  bus topic listener with session
2.       Persist data in cosmos and blob
3.       Publish data on topic 
4.       Logging 
