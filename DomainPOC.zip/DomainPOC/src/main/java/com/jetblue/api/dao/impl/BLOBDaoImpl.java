package com.jetblue.api.dao.impl;

import java.io.IOException;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jetblue.api.dao.IBlobDao;
import com.jetblue.azure.jbms.config.BLOBProperties;
import com.jetblue.jbms.api.exception.model.DomainException;
import com.jetblue.jbms.constant.ALL_ERROR_CODE;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
@Component
public class BLOBDaoImpl implements IBlobDao{
	@Autowired
	private CloudBlobContainer cloudBlobContainer;
	@Autowired
    private BLOBProperties blobProperties;
	@Override
	public void uploadData(String blobPath, String body) throws DomainException   {
		// TODO Auto-generated method stub
		
		try {
			cloudBlobContainer.getBlockBlobReference(blobProperties.getRootFolderLocation()+blobPath).uploadText(body);
		} catch (StorageException e) {
			// TODO Auto-generated catch block
			throw new DomainException(ALL_ERROR_CODE.GLDFLTDAO0001.toString(),e.getErrorCode() , "uploadBLob", e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new DomainException(ALL_ERROR_CODE.GLDFLTDAO0001.toString(),"111" , "uploadBLob", e);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			throw new DomainException(ALL_ERROR_CODE.GLDFLTDAO0001.toString(),e.getReason() , "uploadBLob", e);
		}
	}

}
