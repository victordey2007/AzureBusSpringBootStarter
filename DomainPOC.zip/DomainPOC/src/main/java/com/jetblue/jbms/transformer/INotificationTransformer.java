package com.jetblue.jbms.transformer;

import com.jetblue.jbms.api.exception.model.DomainException;
import com.jetblue.jbms.api.model.notification.NotificationRequest;

public interface INotificationTransformer {
	public NotificationRequest transformRequest(String data) throws DomainException ;
}
