package com.jetblue.azure.jbms.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.time.Duration;
import com.microsoft.azure.servicebus.primitives.ConnectionStringBuilder;
import com.microsoft.azure.servicebus.TopicClient;
@Configuration
public class OutBoundTopicConfig {
	@Value("${azure.servicebus.connection-string}")
	private String connectionUrl;

	@Value("${azure.servicebus.outboundtopic}")
	private String pubTopicName;
	
	@Value("#{new Integer('${azure.servicebus.operationtimeout}')}")
	private int operationTimeout;


	@Bean(name="outboundtopic")
	public TopicClient TopicClient() throws Exception {
		System.out.println("******"+connectionUrl);
		ConnectionStringBuilder csb = new ConnectionStringBuilder(connectionUrl, pubTopicName);
		csb.setOperationTimeout(Duration.ofSeconds(operationTimeout));
		try {
			TopicClient tc= new TopicClient(csb);
			return tc;
		} catch (Exception ex) {
			throw ex;
		}
	}
}
