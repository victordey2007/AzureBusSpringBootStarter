package com.jetblue.application;


import com.jetblue.azure.jbms.config.SrvBUSProperties;

import com.jetblue.jbms.api.handlerimpl.DomainHandlerImpl;

import com.microsoft.azure.servicebus.*;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import java.time.Duration;

@SpringBootApplication(scanBasePackages={"com.jetblue"})
public class Application implements CommandLineRunner {

  
    @Autowired
    private SubscriptionClient subscriptionClient;
    
    @Autowired
    private SrvBUSProperties busProperties;
    
    @Autowired
    private DomainHandlerImpl handler;
    
   
    public static void main(String[] args) {
        SpringApplication.run(Application.class);
    }

    public void run(String... var1) throws ServiceBusException, InterruptedException {
      
    	  
        receiveSubscriptionMessage();
    }

    // NOTE: Please be noted that below are the minimum code for demonstrating the usage of autowired clients.
   



    private void receiveSubscriptionMessage() throws ServiceBusException, InterruptedException {
        subscriptionClient.registerSessionHandler(handler, new SessionHandlerOptions(busProperties.getMaxConcurrentSessions(), busProperties.getMaxConcurrentCallsPerSession(), busProperties.isAutoComplete(),Duration.ofSeconds(busProperties.getMaxAutoRenewDuration()), Duration.ofSeconds(busProperties.getMessageWaitDuration())));
       
    }

   
}