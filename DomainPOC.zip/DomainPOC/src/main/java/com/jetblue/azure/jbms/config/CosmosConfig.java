package com.jetblue.azure.jbms.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.jetblue.jbms.service.impl.DomainServiceImpl;

import com.microsoft.azure.documentdb.DocumentClient;

@Configuration
@ConditionalOnClass(DomainServiceImpl.class)
@EnableConfigurationProperties(CosmosProperties.class)
public class CosmosConfig {

	@Autowired
	private CosmosProperties properties;
	

	@Bean
	public DocumentClient documentClient() {
		return new DocumentClient(properties.getUri(), properties.getKey(), null, null);	
	}
}
