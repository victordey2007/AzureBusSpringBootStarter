package com.jetblue.jbms.api.handler;

import com.microsoft.azure.servicebus.ISessionHandler;

public interface IDomainHandler extends ISessionHandler {

}
