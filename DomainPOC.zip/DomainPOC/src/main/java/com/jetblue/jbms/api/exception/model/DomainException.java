package com.jetblue.jbms.api.exception.model;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;



public class DomainException extends Exception {
	
	private static final long serialVersionUID = 1L;
	private DomainErrorResponse errorResponse = null;
	
	public DomainException( String attr, String internalCode, String code, String method, Exception ex) {
		
		errorResponse = new DomainErrorResponse();
		List<DomainError> err = new ArrayList<>();
		DomainError error = new DomainError();
		error.setAttr(attr);
		error.setDetail(ex.getMessage());
		
		error.setCode(code);
		error.setInternalCode(internalCode);
		error.setException(getStackTrace(ex));
		error.setMethod(method);
		err.add(error);
		errorResponse.setError(err);
	}

	public DomainException( String internalCode, String code,String servicemethodname, Exception ex) {
		errorResponse = new DomainErrorResponse();
		List<DomainError> err = new ArrayList<>();
		DomainError error = new DomainError();
		
		error.setDetail(ex.getMessage());
	
		error.setCode(code);
		error.setInternalCode(internalCode);
		error.setException(getStackTrace(ex));
		err.add(error);
		errorResponse.setError(err);
	}

	private static String getStackTrace(final Throwable throwable) {
		  final StringWriter sw = new StringWriter();
		     final PrintWriter pw = new PrintWriter(sw, true);
		     throwable.printStackTrace(pw);
		     return sw.getBuffer().toString();
	}

	public DomainErrorResponse getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(DomainErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}
	
}
