package com.jetblue.jbms.constant;

public enum ALL_CONSTANTS {

	LOG_MODULE_NAME("domain-service-name"), LOG_PREFIX("Domain --> "), INVALID("invalid"), BLANK("blank"),
	BASIC("BASIC"), DETAILED("DETAILED"), QUERY_EXECUTED("query executed"), DOMAIN_URL("domainURL"),
	QUERY_EXEC_TIME("query execution time"), NOT_NUL_NOT_EMPTY("cannot be null or empty"), JB_CUSTOMER_RQ("JbCustomerRequest"),
	LOOKUP_LEVEL("lookupLevel"), QUERY("query"), DATE_FORMAT_EXCEPTION("date format exception"), FORMATTER("formatter"),
	DATE_FORMAT("yyyy-MM-dd"), DATE_TIME_FORMAT("yyyy-MM-dd'T'HH:mm:ss"), DATE_TIME_MILLISEC_FORMAT("yyyy-MM-dd'T'HH:mm:ss.SS"),
	DATE_TIME_ZONE_FORMAT("yyyy-MM-dd'T'HH:mm:ss.SSZZ"),  DATE_TIME_SPACE_FORMAT("yyyy-MM-dd' 'HH:mm:ss"), DATE_TIME_SPACE_MILLI_FORMAT("yyyy-MM-dd' 'HH:mm:ss.SS"),
	DATE_TIME_SPACE_ZONE_FORMAT("yyyy-MM-dd' 'HH:mm:ss.SSZZ");

	private String value;
	ALL_CONSTANTS(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
