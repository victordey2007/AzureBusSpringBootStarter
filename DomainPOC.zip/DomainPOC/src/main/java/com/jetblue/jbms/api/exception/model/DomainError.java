package com.jetblue.jbms.api.exception.model;

import java.io.Serializable;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
	
@JsonPropertyOrder({
	"attr",
	"code",
	"detail",
	"internalCode"
})
public class DomainError implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("attr")
	private String attr;
	@JsonProperty("code")
	private String code;
	@JsonProperty("detail")
	private String detail;
	@JsonProperty("internalCode")
	private String internalCode;
	@JsonProperty("method")
	private String method;
	
	@JsonIgnore
	private String exception;
	
	@JsonProperty("attr")
	public String getAttr() {
		return attr;
	}
	
	@JsonProperty("attr")
	public void setAttr(String attr) {
		this.attr = attr;
	}
	
	@JsonProperty("method")
	public String getMethod() {
		return method;
	}
	
	@JsonProperty("method")
	public void setMethod(String method) {
		this.method = method;
	}

	@JsonProperty("code")
	public String getCode() {
		return code;
	}
	
	@JsonProperty("code")
	public void setCode(String code) {
		this.code = code;
	}
	
	@JsonProperty("detail")
	public String getDetail() {
		return detail;
	}
	
	@JsonProperty("detail")
	public void setDetail(String detail) {
		this.detail = detail;
	}
	
	@JsonProperty("internalCode")
	public String getInternalCode() {
		return internalCode;
	}
	
	@JsonProperty("internalCode")
	public void setInternalCode(String internalCode) {
		this.internalCode = internalCode;
	}



	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}
}
