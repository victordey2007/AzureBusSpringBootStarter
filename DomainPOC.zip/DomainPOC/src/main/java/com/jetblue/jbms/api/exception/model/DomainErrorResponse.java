package com.jetblue.jbms.api.exception.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
	"errors"
})
public class DomainErrorResponse implements Serializable {
	
	private static final long serialVersionUID = 7089759751629998802L;

	@JsonProperty("errors")
	private List<DomainError> error;

	public List<DomainError> getError() {
		return error;
	}

	public void setError(List<DomainError> error) {
		this.error = error;
	}
	
	
}
