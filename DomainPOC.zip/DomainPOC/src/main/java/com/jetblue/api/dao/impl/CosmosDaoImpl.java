package com.jetblue.api.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jetblue.api.dao.ICosmosDao;
import com.jetblue.azure.jbms.config.CosmosProperties;

import com.jetblue.jbms.api.exception.model.DomainException;
import com.jetblue.jbms.constant.ALL_ERROR_CODE;
import com.microsoft.azure.documentdb.DocumentClient;
import com.microsoft.azure.documentdb.DocumentClientException;
@Component
public class CosmosDaoImpl implements ICosmosDao  {
	@Autowired
	private DocumentClient documentClient;
	@Autowired
	private CosmosProperties cosmosProperties; 
	
	public void saveData(Object nm)  throws DomainException
	{
		
	
		String collectionLink = String.format("/dbs/%s/colls/%s", cosmosProperties.getDatabase(),cosmosProperties.getCollection());
		try {
			documentClient.upsertDocument(collectionLink, nm, null, true);
		} catch (DocumentClientException e) {
			// TODO Auto-generated catch block
			throw new DomainException(ALL_ERROR_CODE.GLDFLTDAO0001.toString(),e.getError().getCode() , "transformRequest", e);
		}
		
	}
}
