package com.jetblue.azure.jbms.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


import com.jetblue.jbms.service.impl.DomainServiceImpl;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;


@Configuration
@ConditionalOnClass(DomainServiceImpl.class)
@EnableConfigurationProperties(BLOBProperties.class)
public class BLOBConfig   {
	
	

	@Autowired
    private BLOBProperties blobProperties;

	
	@Bean
	public CloudBlobContainer cloudBlobContainer() throws Exception
	{
		try {
			CloudStorageAccount account = CloudStorageAccount.parse(blobProperties.getConnectionString());
			CloudBlobClient blobClient = account.createCloudBlobClient();
			CloudBlobContainer cloudBlobContainer = blobClient.getContainerReference(blobProperties.getContainerName());
			return cloudBlobContainer;
		}  catch (Exception ex) {
			throw ex;
		}
		
		
	}

}
