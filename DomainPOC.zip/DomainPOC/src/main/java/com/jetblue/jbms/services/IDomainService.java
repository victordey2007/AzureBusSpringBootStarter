package com.jetblue.jbms.services;

import com.jetblue.jbms.api.exception.model.DomainException;
import com.microsoft.azure.servicebus.IMessage;


public interface IDomainService {
	
	public void PersistAndPublishSegregatedNMRequest(IMessage message) ;

}
