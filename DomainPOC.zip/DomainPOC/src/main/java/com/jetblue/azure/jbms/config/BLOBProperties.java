package com.jetblue.azure.jbms.config;



import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "azure.blob")
public class BLOBProperties {
	
	public String getConnectionString() {
		return connectionString;
	}
	public void setConnectionString(String connectionString) {
		this.connectionString = connectionString;
	}
	public String getContainerName() {
		return containerName;
	}
	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}
	//@Value("${azure.blob.connectionString}")
	private String connectionString;
	//@Value("${azure.blob.containerName}")
	private String containerName;
	private String rootFolderLocation;
	public String getRootFolderLocation() {
		return rootFolderLocation;
	}
	public void setRootFolderLocation(String rootFolderLocation) {
		this.rootFolderLocation = rootFolderLocation;
	}
 
}
